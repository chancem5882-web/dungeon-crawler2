import os
import re
import uuid
import sqlite3
from flask import Flask, render_template, request, redirect, jsonify, send_from_directory, abort
from werkzeug.utils import secure_filename

app = Flask(__name__)

STATS = ["Strength", "Intelligence", "Dexterity", "Constitution", "Charisma"]


def storage_info():
    persistent = "/var/data"
    fallback = os.path.join(os.getcwd(), "data")
    if os.path.exists(persistent):
        root = persistent
        mode = "PERSISTENT"
    else:
        root = fallback
        mode = "EPHEMERAL"
    uploads = os.path.join(root, "uploads")
    os.makedirs(root, exist_ok=True)
    os.makedirs(uploads, exist_ok=True)
    return {"root": root, "uploads": uploads, "db": os.path.join(root, "dcc2.db"), "mode": mode}

STORAGE = storage_info()


def conn():
    c = sqlite3.connect(STORAGE["db"], timeout=20)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL;")
    return c


def columns(table):
    with conn() as db:
        return [r["name"] for r in db.execute(f"PRAGMA table_info({table})").fetchall()]


def add_column_if_missing(table, col, definition):
    if col not in columns(table):
        with conn() as db:
            db.execute(f"ALTER TABLE {table} ADD COLUMN {col} {definition}")
            db.commit()


def init_db():
    with conn() as db:
        db.execute("""
        CREATE TABLE IF NOT EXISTS characters(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            image TEXT DEFAULT ''
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS stats(
            char_id TEXT NOT NULL,
            stat TEXT NOT NULL,
            base INTEGER DEFAULT 10,
            buff INTEGER DEFAULT 0,
            equip INTEGER DEFAULT 0,
            PRIMARY KEY(char_id, stat)
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS meta(
            char_id TEXT PRIMARY KEY,
            level INTEGER DEFAULT 1,
            hp INTEGER DEFAULT 100,
            max_hp INTEGER DEFAULT 100,
            gold INTEGER DEFAULT 0,
            views INTEGER DEFAULT 0,
            followers INTEGER DEFAULT 0,
            favorites INTEGER DEFAULT 0,
            equipment TEXT DEFAULT '',
            spells TEXT DEFAULT '',
            class_text TEXT DEFAULT '',
            race_text TEXT DEFAULT '',
            inventory TEXT DEFAULT ''
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS parsed_skills(
            char_id TEXT NOT NULL,
            name TEXT NOT NULL,
            val INTEGER DEFAULT 0,
            PRIMARY KEY(char_id, name)
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS parsed_percentages(
            char_id TEXT NOT NULL,
            name TEXT NOT NULL,
            val INTEGER DEFAULT 0,
            PRIMARY KEY(char_id, name)
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS parsed_conditions(
            char_id TEXT NOT NULL,
            name TEXT NOT NULL,
            PRIMARY KEY(char_id, name)
        )
        """)
        db.execute("""
        CREATE TABLE IF NOT EXISTS effects(
            id TEXT PRIMARY KEY,
            char_id TEXT NOT NULL,
            name TEXT NOT NULL,
            value INTEGER DEFAULT 0,
            duration INTEGER DEFAULT 0,
            duration_type TEXT DEFAULT 'rounds',
            is_buff INTEGER DEFAULT 1
        )
        """)
        db.commit()

    # automatic migration for older zips/dbs
    for col, definition in [
        ("gold", "INTEGER DEFAULT 0"),
        ("views", "INTEGER DEFAULT 0"),
        ("followers", "INTEGER DEFAULT 0"),
        ("favorites", "INTEGER DEFAULT 0"),
        ("equipment", "TEXT DEFAULT ''"),
        ("spells", "TEXT DEFAULT ''"),
        ("class_text", "TEXT DEFAULT ''"),
        ("race_text", "TEXT DEFAULT ''"),
        ("inventory", "TEXT DEFAULT ''"),
    ]:
        add_column_if_missing("meta", col, definition)
    if "image" not in columns("characters"):
        add_column_if_missing("characters", "image", "TEXT DEFAULT ''")


def safe_int(v, default=0):
    try:
        if v is None or v == "":
            return default
        return int(float(v))
    except Exception:
        return default


def clean_name(s):
    s = (s or "").lower().replace("skill", "")
    s = re.sub(r"[^a-zA-Z0-9 %_\-']+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def mod(total):
    return total // 5


def parse_equipment(text):
    stat_bonus = {s: 0 for s in STATS}
    skill_bonus = {}
    percent_bonus = {}
    conditions = []
    errors = []

    for line_no, raw in enumerate((text or "").splitlines(), start=1):
        line = raw.strip().lower()
        if not line:
            continue
        parsed_any = False
        try:
            # special conditions in parentheses
            for cond in re.findall(r"\((.*?)\)", line):
                cond = clean_name(cond)
                if cond and cond not in conditions:
                    conditions.append(cond)
                    parsed_any = True
            line_no_conditions = re.sub(r"\(.*?\)", " ", line)

            # percentages: +10% attack speed OR attack speed +10% OR crit chance: 15%
            for m in re.finditer(r"([+-]?\d+)\s*%\s*([a-zA-Z][a-zA-Z '\-]*)|([a-zA-Z][a-zA-Z '\-]*)[:=]?\s*([+-]?\d+)\s*%", line_no_conditions):
                a, b, c, d = m.groups()
                val = safe_int(a or d, None)
                name = clean_name(b or c)
                if val is not None and name:
                    percent_bonus[name] = percent_bonus.get(name, 0) + val
                    parsed_any = True

            remaining = re.sub(r"([+-]?\d+\s*%\s*[a-zA-Z][a-zA-Z '\-]*)|([a-zA-Z][a-zA-Z '\-]*[:=]?\s*[+-]?\d+\s*%)", " ", line_no_conditions)

            # normal bonuses: +2 STR, STR +2, +3 bomb handling, bomb handling +3
            for m in re.finditer(r"([+-]?\d+)\s*([a-zA-Z][a-zA-Z '\-]*)|([a-zA-Z][a-zA-Z '\-]*)[:=]?\s*([+-]?\d+)", remaining):
                a, b, c, d = m.groups()
                val = safe_int(a or d, None)
                name = clean_name(b or c)
                if val is None or not name:
                    continue
                matched = False
                for stat in STATS:
                    if name == stat.lower() or name.startswith(stat[:3].lower()):
                        stat_bonus[stat] += val
                        matched = True
                        parsed_any = True
                        break
                if not matched:
                    skill_bonus[name] = skill_bonus.get(name, 0) + val
                    parsed_any = True
        except Exception as e:
            errors.append(f"Line {line_no}: could not parse '{raw}'")
        if not parsed_any:
            # do not warn for flavor item names with no bonuses; this keeps UI clean
            pass
    return stat_bonus, skill_bonus, percent_bonus, conditions, errors


def ensure_character(cid):
    with conn() as db:
        row = db.execute("SELECT * FROM characters WHERE id=?", (cid,)).fetchone()
        return row


def refresh_parsed_tables(cid, equipment):
    stat_b, skill_b, percent_b, conds, errors = parse_equipment(equipment)
    with conn() as db:
        for stat in STATS:
            db.execute("UPDATE stats SET equip=? WHERE char_id=? AND stat=?", (stat_b[stat], cid, stat))
        db.execute("DELETE FROM parsed_skills WHERE char_id=?", (cid,))
        db.execute("DELETE FROM parsed_percentages WHERE char_id=?", (cid,))
        db.execute("DELETE FROM parsed_conditions WHERE char_id=?", (cid,))
        for name, val in skill_b.items():
            db.execute("INSERT OR REPLACE INTO parsed_skills VALUES (?, ?, ?)", (cid, name, val))
        for name, val in percent_b.items():
            db.execute("INSERT OR REPLACE INTO parsed_percentages VALUES (?, ?, ?)", (cid, name, val))
        for cond in conds:
            db.execute("INSERT OR REPLACE INTO parsed_conditions VALUES (?, ?)", (cid, cond))
        db.commit()
    return errors


@app.route("/")
def index():
    with conn() as db:
        chars = db.execute("SELECT id, name, image FROM characters ORDER BY name").fetchall()
    return render_template("index.html", chars=chars, storage=STORAGE)


@app.route("/create", methods=["POST"])
def create():
    cid = str(uuid.uuid4())
    name = request.form.get("name") or "Unnamed Crawler"
    with conn() as db:
        db.execute("INSERT INTO characters(id, name, image) VALUES (?, ?, '')", (cid, name))
        db.execute("INSERT INTO meta(char_id) VALUES (?)", (cid,))
        for stat in STATS:
            db.execute("INSERT INTO stats(char_id, stat, base, buff, equip) VALUES (?, ?, 10, 0, 0)", (cid, stat))
        db.commit()
    return redirect(f"/c/{cid}")


@app.route("/image/<filename>")
def image(filename):
    return send_from_directory(STORAGE["uploads"], filename)


@app.route("/upload/<cid>", methods=["POST"])
def upload(cid):
    if not ensure_character(cid):
        abort(404)
    file = request.files.get("image")
    if file and file.filename:
        base = secure_filename(file.filename)
        ext = os.path.splitext(base)[1].lower()
        filename = f"{cid}_{uuid.uuid4().hex}{ext}"
        save_path = os.path.join(STORAGE["uploads"], filename)
        file.save(save_path)
        with conn() as db:
            db.execute("UPDATE characters SET image=? WHERE id=?", (f"/image/{filename}", cid))
            db.commit()
    return redirect(f"/c/{cid}")


@app.route("/autosave/<cid>", methods=["POST"])
def autosave(cid):
    if not ensure_character(cid):
        abort(404)
    data = request.json or {}
    equipment = data.get("equipment", "")
    with conn() as db:
        db.execute("""
            UPDATE meta SET
                level=?, hp=?, max_hp=?, gold=?, views=?, followers=?, favorites=?,
                equipment=?, spells=?, class_text=?, race_text=?, inventory=?
            WHERE char_id=?
        """, (
            safe_int(data.get("level"), 1),
            safe_int(data.get("hp"), 100),
            max(safe_int(data.get("max_hp"), 100), 1),
            safe_int(data.get("gold"), 0),
            safe_int(data.get("views"), 0),
            safe_int(data.get("followers"), 0),
            safe_int(data.get("favorites"), 0),
            equipment,
            data.get("spells", ""),
            data.get("class_text", ""),
            data.get("race_text", ""),
            data.get("inventory", ""),
            cid,
        ))
        for stat in STATS:
            db.execute("UPDATE stats SET base=?, buff=? WHERE char_id=? AND stat=?", (
                safe_int(data.get(f"base_{stat}"), 10),
                safe_int(data.get(f"buff_{stat}"), 0),
                cid,
                stat,
            ))
        db.execute("DELETE FROM effects WHERE char_id=?", (cid,))
        for effect in data.get("effects", []):
            name = (effect.get("name") or "").strip()
            if not name:
                continue
            db.execute("INSERT INTO effects VALUES (?, ?, ?, ?, ?, ?, ?)", (
                str(uuid.uuid4()), cid, name,
                safe_int(effect.get("value"), 0),
                safe_int(effect.get("duration"), 0),
                effect.get("duration_type") or "rounds",
                1 if effect.get("is_buff") else 0,
            ))
        db.commit()
    return jsonify({"status": "saved"})


@app.route("/update_parsed/<cid>", methods=["POST"])
def update_parsed(cid):
    if not ensure_character(cid):
        abort(404)
    data = request.json or {}
    equipment = data.get("equipment", "")
    with conn() as db:
        db.execute("UPDATE meta SET equipment=? WHERE char_id=?", (equipment, cid))
        db.commit()
    errors = refresh_parsed_tables(cid, equipment)
    return jsonify({"status": "updated", "errors": errors})


@app.route("/c/<cid>")
def character(cid):
    with conn() as db:
        character = db.execute("SELECT id, name, image FROM characters WHERE id=?", (cid,)).fetchone()
        if not character:
            abort(404)
        meta = db.execute("SELECT * FROM meta WHERE char_id=?", (cid,)).fetchone()
        # ensure any imported/old character has meta/stat rows
        if not meta:
            db.execute("INSERT INTO meta(char_id) VALUES (?)", (cid,))
            db.commit()
            meta = db.execute("SELECT * FROM meta WHERE char_id=?", (cid,)).fetchone()
        existing_stats = {r["stat"] for r in db.execute("SELECT stat FROM stats WHERE char_id=?", (cid,)).fetchall()}
        for stat in STATS:
            if stat not in existing_stats:
                db.execute("INSERT INTO stats(char_id, stat, base, buff, equip) VALUES (?, ?, 10, 0, 0)", (cid, stat))
        db.commit()

        # refresh parsed values from equipment every page load so old characters display correctly
        equipment = meta["equipment"] or ""
    refresh_parsed_tables(cid, equipment)

    with conn() as db:
        character = db.execute("SELECT id, name, image FROM characters WHERE id=?", (cid,)).fetchone()
        meta = db.execute("SELECT * FROM meta WHERE char_id=?", (cid,)).fetchone()
        stat_rows = db.execute("SELECT stat, base, buff, equip FROM stats WHERE char_id=?", (cid,)).fetchall()
        stats = {}
        for r in stat_rows:
            total = safe_int(r["base"]) + safe_int(r["buff"]) + safe_int(r["equip"])
            stats[r["stat"]] = {"base": r["base"], "buff": r["buff"], "equip": r["equip"], "total": total, "mod": mod(total)}
        skills = db.execute("SELECT name, val FROM parsed_skills WHERE char_id=? ORDER BY name", (cid,)).fetchall()
        percentages = db.execute("SELECT name, val FROM parsed_percentages WHERE char_id=? ORDER BY name", (cid,)).fetchall()
        conditions = db.execute("SELECT name FROM parsed_conditions WHERE char_id=? ORDER BY name", (cid,)).fetchall()
        effects = db.execute("SELECT name, value, duration, duration_type, is_buff FROM effects WHERE char_id=?", (cid,)).fetchall()
    return render_template("character.html", cid=cid, character=character, meta=meta, stats=stats, skills=skills, percentages=percentages, conditions=conditions, effects=effects, storage=STORAGE)


init_db()

if __name__ == "__main__":
    app.run(debug=True)
