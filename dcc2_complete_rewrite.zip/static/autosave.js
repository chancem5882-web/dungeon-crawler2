const cid = window.location.pathname.split('/').pop();
const indicator = document.getElementById('save-indicator');
function setStatus(t){ if(indicator) indicator.textContent = t; }
function collectData(){
  const data = {effects:[]};
  document.querySelectorAll('input[name], textarea[name], select[name]').forEach(el=>{
    if(el.type === 'checkbox') data[el.name] = el.checked;
    else data[el.name] = el.value;
  });
  document.querySelectorAll('.effect').forEach(e=>{
    const name = e.querySelector('.effect-name')?.value || '';
    if(!name.trim()) return;
    data.effects.push({
      name,
      value: parseInt(e.querySelector('.effect-value')?.value || '0') || 0,
      duration: parseInt(e.querySelector('.effect-duration')?.value || '0') || 0,
      duration_type: e.querySelector('.effect-duration-type')?.value || 'rounds',
      is_buff: e.querySelector('.effect-is-buff')?.checked || false
    });
  });
  return data;
}
async function saveData(){
  setStatus('Saving...');
  try{
    await fetch(`/autosave/${cid}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(collectData())});
    setStatus('Saved');
  }catch(e){ setStatus('Save failed'); }
}
async function updateParsedBonuses(){
  setStatus('Updating parser...');
  await saveData();
  try{
    await fetch(`/update_parsed/${cid}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({equipment: document.querySelector('[name="equipment"]').value})});
    window.location.reload();
  }catch(e){ setStatus('Parser update failed'); }
}
document.addEventListener('input', ()=>{ clearTimeout(window.saveTimer); window.saveTimer = setTimeout(saveData, 500); });
document.addEventListener('change', ()=>{ clearTimeout(window.saveTimer); window.saveTimer = setTimeout(saveData, 500); });
function addEffect(){
  const wrap = document.createElement('div');
  wrap.className = 'effect';
  wrap.innerHTML = `
    <div class="effect-grid">
      <input class="effect-name" placeholder="Effect name">
      <input class="effect-value" type="number" placeholder="Value">
      <input class="effect-duration" type="number" placeholder="Duration">
      <select class="effect-duration-type"><option value="rounds">rounds</option><option value="hours">hours</option></select>
    </div>
    <label class="check"><input type="checkbox" class="effect-is-buff"> Buff? unchecked = debuff</label>`;
  document.getElementById('effects').appendChild(wrap);
}
