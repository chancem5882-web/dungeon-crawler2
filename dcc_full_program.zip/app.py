import os
import re
import sqlite3
import uuid
from datetime import datetime
from flask import Flask, render_template, request, redirect, jsonify, send_from_directory
from werkzeug.utils import secure_filename

app = Flask(__name__)
DM_PASSWORD = "Cocker Spaniel"
STATS = ["Strength", "Intelligence", "Dexterity", "Constitution", "Charisma"]

# =========================
# STORAGE
# =========================
def get_storage():
    persistent = "/var/data"
    fallback = "./data"
    path = persistent if os.path.exists(persistent) else fallback
    os.makedirs(path, exist_ok=True)
    return {"path": path, "db": os.path.join(path, "db.db")}

STORAGE = get_storage()
UPLOAD_FOLDER = os.path.join(STORAGE["path"], "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# =========================
# DB HELPERS
# =========================
def get_conn():
    conn = sqlite3.connect(STORAGE["db"], timeout=10, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn

def ensure_column(c, table, column, definition):
    existing = [r["name"] for r in c.execute(f"PRAGMA table_info({table})").fetchall()]
    if column not in existing:
        c.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS characters(
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        image TEXT DEFAULT '/static/default.png'
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS stats(
        char_id TEXT,
        stat TEXT,
        base INTEGER DEFAULT 10,
        equip INTEGER DEFAULT 0,
        PRIMARY KEY(char_id, stat)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS meta(
        char_id TEXT PRIMARY KEY,
        level INTEGER DEFAULT 1,
        hp INTEGER DEFAULT 100,
        max_hp INTEGER DEFAULT 100,
        mana INTEGER DEFAULT 50,
        max_mana INTEGER DEFAULT 50,
        gold INTEGER DEFAULT 0,
        views INTEGER DEFAULT 0,
        followers INTEGER DEFAULT 0,
        favorites INTEGER DEFAULT 0,
        equipment TEXT DEFAULT '',
        inventory TEXT DEFAULT '',
        spells TEXT DEFAULT '',
        skills_text TEXT DEFAULT ''
    )
    """)

    # Safe migrations if you already had an older DB.
    for col, definition in [
        ("mana", "INTEGER DEFAULT 50"),
        ("max_mana", "INTEGER DEFAULT 50"),
        ("gold", "INTEGER DEFAULT 0"),
        ("views", "INTEGER DEFAULT 0"),
        ("followers", "INTEGER DEFAULT 0"),
        ("favorites", "INTEGER DEFAULT 0"),
        ("equipment", "TEXT DEFAULT ''"),
        ("inventory", "TEXT DEFAULT ''"),
        ("spells", "TEXT DEFAULT ''"),
        ("skills_text", "TEXT DEFAULT ''"),
    ]:
        ensure_column(c, "meta", col, definition)

    c.execute("""
    CREATE TABLE IF NOT EXISTS skills(
        char_id TEXT,
        name TEXT,
        val INTEGER DEFAULT 0,
        PRIMARY KEY(char_id, name)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS perc(
        char_id TEXT,
        name TEXT,
        val INTEGER DEFAULT 0,
        PRIMARY KEY(char_id, name)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS conditions(
        char_id TEXT,
        name TEXT,
        PRIMARY KEY(char_id, name)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS messages(
        id TEXT PRIMARY KEY,
        target TEXT DEFAULT 'all',
        sender TEXT DEFAULT 'Dungeon AI',
        category TEXT DEFAULT 'announcement',
        content TEXT DEFAULT '',
        created_at TEXT DEFAULT ''
    )
    """)
    ensure_column(c, "messages", "created_at", "TEXT DEFAULT ''")

    c.execute("""
    CREATE TABLE IF NOT EXISTS effects(
        id TEXT PRIMARY KEY,
        target TEXT,
        name TEXT,
        duration INTEGER DEFAULT 1,
        effect_text TEXT DEFAULT ''
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS loot(
        id TEXT PRIMARY KEY,
        char_id TEXT,
        name TEXT,
        item_type TEXT,
        description TEXT,
        effect_text TEXT,
        spell_name TEXT,
        spell_cost INTEGER DEFAULT 0,
        spell_effect TEXT,
        equipped INTEGER DEFAULT 0,
        created_at TEXT DEFAULT ''
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS spells(
        id TEXT PRIMARY KEY,
        char_id TEXT,
        name TEXT,
        cost INTEGER DEFAULT 0,
        description TEXT DEFAULT ''
    )
    """)

    conn.commit()
    conn.close()

# =========================
# PARSING
# =========================
def strip_html(text):
    text = re.sub(r"<br\s*/?>", "\n", text or "", flags=re.I)
    text = re.sub(r"</div>|</p>|</li>", "\n", text, flags=re.I)
    return re.sub(r"<.*?>", "", text)

def clean(v):
    return re.sub(r"\s+", " ", (v or "").lower().replace("skill", "")).strip()

def safe_int(v, default=0):
    try:
        return int(v)
    except Exception:
        return default

def parse_all(text):
    raw = strip_html(text)
    stats = {s: 0 for s in STATS}
    skills = {}
    perc = {}
    conditions = []

    for line in raw.split("\n"):
        line = line.strip()
        if not line:
            continue

        for cond in re.findall(r"\((.*?)\)", line):
            cond = clean(cond)
            if cond and cond not in conditions:
                conditions.append(cond)

        # Percent examples: +10% attack speed OR attack speed +10%
        for m in re.finditer(r"([+-]?\d+)\s*%\s*([a-zA-Z ]+)|([a-zA-Z ]+)\s*([+-]?\d+)\s*%", line.lower()):
            a, b, c, d = m.groups()
            val = safe_int(a or d, None)
            name = clean(b or c)
            if val is not None and name:
                perc[name] = perc.get(name, 0) + val

        # Remove percentages before normal parsing so they don't double count as skills.
        line_no_percent = re.sub(r"([+-]?\d+\s*%\s*[a-zA-Z ]+)|([a-zA-Z ]+\s*[+-]?\d+\s*%)", "", line.lower())

        # Stat/skill examples: +3 STR OR bomb handling +2
        for m in re.finditer(r"([+-]?\d+)\s*([a-zA-Z ]+)|([a-zA-Z ]+)\s*([+-]?\d+)", line_no_percent):
            a, b, c, d = m.groups()
            val = safe_int(a or d, None)
            name = clean(b or c)
            if val is None or not name:
                continue

            matched = False
            for stat in STATS:
                if name.startswith(stat[:3].lower()):
                    stats[stat] += val
                    matched = True
                    break
            if not matched:
                skills[name] = skills.get(name, 0) + val

    return stats, skills, perc, conditions

def compute_character(c, cid):
    meta = c.execute("SELECT * FROM meta WHERE char_id=?", (cid,)).fetchone()
    if not meta:
        return None

    equipment = meta["equipment"] or ""
    skills_text = meta["skills_text"] or ""

    eq_stats, eq_skills, eq_perc, eq_cond = parse_all(equipment)
    sk_stats, sk_skills, sk_perc, sk_cond = parse_all(skills_text)

    active_effects = c.execute("SELECT * FROM effects WHERE target=?", (cid,)).fetchall()
    effect_stats = {s: 0 for s in STATS}
    effect_skills, effect_perc, effect_cond = {}, {}, []

    for e in active_effects:
        es, esk, ep, ec = parse_all(e["effect_text"])
        for s, v in es.items():
            effect_stats[s] += v
        for k, v in esk.items():
            effect_skills[k] = effect_skills.get(k, 0) + v
        for k, v in ep.items():
            effect_perc[k] = effect_perc.get(k, 0) + v
        effect_cond += ec

    loot_items = c.execute("SELECT * FROM loot WHERE char_id=?", (cid,)).fetchall()
    loot_stats = {s: 0 for s in STATS}
    loot_skills, loot_perc, loot_cond = {}, {}, []
    for item in loot_items:
        if item["equipped"]:
            ls, lsk, lp, lc = parse_all((item["effect_text"] or "") + "\n" + (item["spell_effect"] or ""))
            for s, v in ls.items():
                loot_stats[s] += v
            for k, v in lsk.items():
                loot_skills[k] = loot_skills.get(k, 0) + v
            for k, v in lp.items():
                loot_perc[k] = loot_perc.get(k, 0) + v
            loot_cond += lc

    final_skills, final_perc = {}, {}
    for group in [eq_skills, sk_skills, effect_skills, loot_skills]:
        for k, v in group.items():
            final_skills[k] = final_skills.get(k, 0) + v
    for group in [eq_perc, sk_perc, effect_perc, loot_perc]:
        for k, v in group.items():
            final_perc[k] = final_perc.get(k, 0) + v
    final_cond = sorted(set(eq_cond + sk_cond + effect_cond + loot_cond))

    stats_raw = c.execute("SELECT * FROM stats WHERE char_id=?", (cid,)).fetchall()
    stats = {}
    for row in stats_raw:
        stat = row["stat"]
        equip_total = eq_stats[stat] + sk_stats[stat] + effect_stats[stat] + loot_stats[stat]
        total = row["base"] + equip_total
        stats[stat] = {"base": row["base"], "equip": equip_total, "total": total, "mod": total // 5}

    return stats, final_skills, final_perc, final_cond, active_effects, loot_items

def persist_parsed(c, cid, stats, skills, perc, conds):
    for stat, data in stats.items():
        c.execute("UPDATE stats SET equip=? WHERE char_id=? AND stat=?", (data["equip"], cid, stat))
    c.execute("DELETE FROM skills WHERE char_id=?", (cid,))
    for k, v in skills.items():
        c.execute("INSERT OR REPLACE INTO skills VALUES(?,?,?)", (cid, k, v))
    c.execute("DELETE FROM perc WHERE char_id=?", (cid,))
    for k, v in perc.items():
        c.execute("INSERT OR REPLACE INTO perc VALUES(?,?,?)", (cid, k, v))
    c.execute("DELETE FROM conditions WHERE char_id=?", (cid,))
    for cond in conds:
        c.execute("INSERT OR REPLACE INTO conditions VALUES(?,?)", (cid, cond))

# =========================
# ROUTES
# =========================
@app.route("/")
def home():
    conn = get_conn()
    chars = conn.execute("SELECT * FROM characters ORDER BY name").fetchall()
    conn.close()
    return render_template("index.html", chars=chars)

@app.route("/create", methods=["POST"])
def create():
    cid = str(uuid.uuid4())
    name = request.form.get("name", "Crawler")
    conn = get_conn()
    c = conn.cursor()
    c.execute("INSERT INTO characters VALUES(?,?,?)", (cid, name, "/static/default.png"))
    for stat in STATS:
        c.execute("INSERT INTO stats VALUES(?,?,?,?)", (cid, stat, 10, 0))
    c.execute("INSERT INTO meta VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (cid, 1, 100, 100, 50, 50, 0, 0, 0, 0, "", "", "", ""))
    conn.commit()
    conn.close()
    return redirect(f"/c/{cid}")

@app.route("/upload/<cid>", methods=["POST"])
def upload(cid):
    file = request.files.get("image")
    if file and file.filename:
        filename = f"{cid}_{secure_filename(file.filename)}"
        save_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(save_path)
        conn = get_conn()
        conn.execute("UPDATE characters SET image=? WHERE id=?", (f"/image/{filename}", cid))
        conn.commit()
        conn.close()
    return redirect(f"/c/{cid}")

@app.route("/image/<filename>")
def image(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route("/update/<cid>", methods=["POST"])
def update(cid):
    data = request.json or {}
    conn = get_conn()
    c = conn.cursor()
    c.execute("""
    UPDATE meta SET level=?,hp=?,max_hp=?,mana=?,max_mana=?,gold=?,views=?,followers=?,favorites=?,equipment=?,inventory=?,spells=?,skills_text=?
    WHERE char_id=?
    """, (
        safe_int(data.get("level"), 1), safe_int(data.get("hp"), 100), safe_int(data.get("max_hp"), 100),
        safe_int(data.get("mana"), 50), safe_int(data.get("max_mana"), 50), safe_int(data.get("gold"), 0),
        safe_int(data.get("views"), 0), safe_int(data.get("followers"), 0), safe_int(data.get("favorites"), 0),
        data.get("equipment", ""), data.get("inventory", ""), data.get("spells", ""), data.get("skills_text", ""), cid
    ))
    for stat in STATS:
        c.execute("UPDATE stats SET base=? WHERE char_id=? AND stat=?", (safe_int(data.get(f"base_{stat}"), 10), cid, stat))
    computed = compute_character(c, cid)
    if computed:
        stats, skills, perc, conds, _, _ = computed
        persist_parsed(c, cid, stats, skills, perc, conds)
    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})

@app.route("/cast_spell/<spell_id>", methods=["POST"])
def cast_spell(spell_id):
    conn = get_conn()
    c = conn.cursor()
    spell = c.execute("SELECT * FROM spells WHERE id=?", (spell_id,)).fetchone()
    if not spell:
        conn.close()
        return jsonify({"status": "error", "message": "Spell not found"}), 404
    meta = c.execute("SELECT mana FROM meta WHERE char_id=?", (spell["char_id"],)).fetchone()
    mana = meta["mana"] if meta else 0
    cost = spell["cost"] or 0
    if mana < cost:
        conn.close()
        return jsonify({"status": "error", "message": "Not enough mana"}), 400
    new_mana = mana - cost
    c.execute("UPDATE meta SET mana=? WHERE char_id=?", (new_mana, spell["char_id"]))
    c.execute("INSERT INTO messages VALUES(?,?,?,?,?,?)", (str(uuid.uuid4()), spell["char_id"], "SYSTEM", "spell", f"Cast {spell['name']} for {cost} mana.", datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()
    return jsonify({"status": "ok", "mana": new_mana})

@app.route("/toggle_loot/<loot_id>", methods=["POST"])
def toggle_loot(loot_id):
    conn = get_conn()
    c = conn.cursor()
    item = c.execute("SELECT * FROM loot WHERE id=?", (loot_id,)).fetchone()
    if item:
        c.execute("UPDATE loot SET equipped=? WHERE id=?", (0 if item["equipped"] else 1, loot_id))
        computed = compute_character(c, item["char_id"])
        if computed:
            stats, skills, perc, conds, _, _ = computed
            persist_parsed(c, item["char_id"], stats, skills, perc, conds)
    conn.commit()
    conn.close()
    return jsonify({"status": "ok"})

@app.route("/dm", methods=["GET", "POST"])
def dm():
    if request.method == "POST" and request.form.get("password", "") != DM_PASSWORD:
        return "ACCESS DENIED"
    conn = get_conn()
    c = conn.cursor()
    chars_raw = c.execute("""
    SELECT characters.id, characters.name, characters.image, meta.level, meta.hp, meta.max_hp, meta.mana, meta.max_mana, meta.gold
    FROM characters JOIN meta ON characters.id = meta.char_id ORDER BY characters.name
    """).fetchall()
    all_data = []
    for ch in chars_raw:
        computed = compute_character(c, ch["id"])
        if computed:
            stats, skills, perc, conds, effects, loot_items = computed
            all_data.append({"char": ch, "stats": stats, "skills": skills, "percs": perc, "conds": conds, "effects": effects, "loot": loot_items})
    messages = c.execute("SELECT * FROM messages ORDER BY rowid DESC LIMIT 50").fetchall()
    conn.close()
    return render_template("dm.html", chars=all_data, messages=messages)

@app.route("/send_message", methods=["POST"])
def send_message():
    conn = get_conn()
    conn.execute("INSERT INTO messages VALUES(?,?,?,?,?,?)", (
        str(uuid.uuid4()), request.form.get("target", "all"), request.form.get("sender", "Dungeon AI"),
        request.form.get("category", "announcement"), request.form.get("content", ""), datetime.utcnow().isoformat()
    ))
    conn.commit()
    conn.close()
    return redirect("/dm")

@app.route("/apply_effect", methods=["POST"])
def apply_effect():
    conn = get_conn()
    c = conn.cursor()
    targets = request.form.getlist("targets")
    for t in targets:
        c.execute("INSERT INTO effects VALUES(?,?,?,?,?)", (str(uuid.uuid4()), t, request.form.get("name", "Effect"), safe_int(request.form.get("duration"), 1), request.form.get("effect_text", "")))
        computed = compute_character(c, t)
        if computed:
            stats, skills, perc, conds, _, _ = computed
            persist_parsed(c, t, stats, skills, perc, conds)
    conn.commit()
    conn.close()
    return redirect("/dm")

@app.route("/tick_effects")
def tick_effects():
    conn = get_conn()
    c = conn.cursor()
    effects = c.execute("SELECT * FROM effects").fetchall()
    affected = set()
    for e in effects:
        affected.add(e["target"])
        new_duration = e["duration"] - 1
        if new_duration <= 0:
            c.execute("DELETE FROM effects WHERE id=?", (e["id"],))
        else:
            c.execute("UPDATE effects SET duration=? WHERE id=?", (new_duration, e["id"]))
    for cid in affected:
        computed = compute_character(c, cid)
        if computed:
            stats, skills, perc, conds, _, _ = computed
            persist_parsed(c, cid, stats, skills, perc, conds)
    conn.commit()
    conn.close()
    return redirect("/dm")

@app.route("/dm_hp", methods=["POST"])
def dm_hp():
    cid = request.form.get("char_id")
    amount = safe_int(request.form.get("amount"), 0)
    mode = request.form.get("mode", "damage")
    conn = get_conn()
    c = conn.cursor()
    meta = c.execute("SELECT hp,max_hp FROM meta WHERE char_id=?", (cid,)).fetchone()
    if meta:
        hp = meta["hp"]
        if mode == "heal":
            hp = min(meta["max_hp"], hp + amount)
        elif mode == "set":
            hp = max(0, amount)
        else:
            hp = max(0, hp - amount)
        c.execute("UPDATE meta SET hp=? WHERE char_id=?", (hp, cid))
    conn.commit()
    conn.close()
    return redirect("/dm")

@app.route("/grant_loot", methods=["POST"])
def grant_loot():
    conn = get_conn()
    c = conn.cursor()
    targets = request.form.getlist("targets")
    for t in targets:
        c.execute("""
        INSERT INTO loot VALUES(?,?,?,?,?,?,?,?,?,?,?)
        """, (
            str(uuid.uuid4()), t, request.form.get("name", "Loot"), request.form.get("item_type", "equipment"),
            request.form.get("description", ""), request.form.get("effect_text", ""), request.form.get("spell_name", ""),
            safe_int(request.form.get("spell_cost"), 0), request.form.get("spell_effect", ""), 0, datetime.utcnow().isoformat()
        ))
    conn.commit()
    conn.close()
    return redirect("/dm")

@app.route("/add_spell", methods=["POST"])
def add_spell():
    cid = request.form.get("char_id")
    conn = get_conn()
    conn.execute("INSERT INTO spells VALUES(?,?,?,?,?)", (str(uuid.uuid4()), cid, request.form.get("name", "Spell"), safe_int(request.form.get("cost"), 0), request.form.get("description", "")))
    conn.commit()
    conn.close()
    return redirect(f"/c/{cid}")

@app.route("/state/<cid>")
def state(cid):
    conn = get_conn()
    c = conn.cursor()
    computed = compute_character(c, cid)
    meta = c.execute("SELECT * FROM meta WHERE char_id=?", (cid,)).fetchone()
    messages = c.execute("SELECT * FROM messages WHERE target=? OR target='all' ORDER BY rowid DESC LIMIT 20", (cid,)).fetchall()
    conn.close()
    if not computed or not meta:
        return jsonify({"error": "not found"}), 404
    stats, skills, perc, conds, effects, loot_items = computed
    return jsonify({
        "meta": dict(meta),
        "stats": stats,
        "skills": skills,
        "percs": perc,
        "conds": conds,
        "effects": [dict(e) for e in effects],
        "loot": [dict(i) for i in loot_items],
        "messages": [dict(m) for m in messages]
    })

@app.route("/c/<cid>")
def character(cid):
    conn = get_conn()
    c = conn.cursor()
    character = c.execute("SELECT * FROM characters WHERE id=?", (cid,)).fetchone()
    meta = c.execute("SELECT * FROM meta WHERE char_id=?", (cid,)).fetchone()
    computed = compute_character(c, cid)
    spells = c.execute("SELECT * FROM spells WHERE char_id=? ORDER BY name", (cid,)).fetchall()
    messages = c.execute("SELECT * FROM messages WHERE target=? OR target='all' ORDER BY rowid DESC LIMIT 20", (cid,)).fetchall()
    conn.close()
    if not character or not meta or not computed:
        return "Character not found", 404
    stats, skills, percs, conds, effects, loot_items = computed
    return render_template("character.html", character=character, meta=meta, stats=stats, skills=skills, percs=percs, conds=conds, effects=effects, messages=messages, loot=loot_items, spells=spells)

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
