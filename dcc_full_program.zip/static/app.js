const cid = window.location.pathname.split('/').pop();
let saveTimer = null;
let polling = null;

function getHTML(id){ const el=document.getElementById(id); return el ? el.innerHTML : ''; }
function setHTML(id, value){ const el=document.getElementById(id); if(el && document.activeElement !== el){ el.innerHTML = value || ''; } }
function val(name){ const el=document.querySelector(`[name="${name}"]`); return el ? el.value : ''; }

function collect(){
  const data = {};
  document.querySelectorAll('input').forEach(el=>{ if(el.name) data[el.name]=el.value; });
  data.equipment = getHTML('equipment');
  data.inventory = getHTML('inventory');
  data.spells = getHTML('spells');
  data.skills_text = getHTML('skills_text');
  return data;
}

async function saveNow(show=false){
  if(!cid || cid === 'dm') return;
  const status=document.getElementById('saveStatus');
  if(status) status.textContent='Saving...';
  await fetch(`/update/${cid}`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(collect())});
  if(status) status.textContent='Saved to Dungeon System';
  if(show) location.reload();
}

function queueSave(){ clearTimeout(saveTimer); saveTimer=setTimeout(()=>saveNow(false), 500); }

document.addEventListener('input', e=>{ if(e.target.matches('input, .richbox')) queueSave(); });
document.addEventListener('keyup', e=>{ if(e.target.classList && e.target.classList.contains('richbox')) queueSave(); });

function renderState(data){
  if(!data || data.error) return;
  const m=data.meta;
  const hpPct = m.max_hp ? Math.max(0, Math.min(100, (m.hp/m.max_hp)*100)) : 0;
  const manaPct = m.max_mana ? Math.max(0, Math.min(100, (m.mana/m.max_mana)*100)) : 0;
  document.getElementById('hpText').textContent = `${m.hp} / ${m.max_hp}`;
  document.getElementById('manaText').textContent = `${m.mana} / ${m.max_mana}`;
  document.getElementById('hpFill').style.width = hpPct + '%';
  document.getElementById('manaFill').style.width = manaPct + '%';

  const statsBox=document.getElementById('statsBox');
  if(statsBox){
    statsBox.innerHTML='';
    Object.entries(data.stats).forEach(([name,d])=>{
      statsBox.innerHTML += `<div class="statcard"><b>${name}</b><div class="bigstat">${d.total}</div><div class="mod">MOD +${d.mod}</div><div class="small">Base ${d.base} | Bonus ${d.equip}</div><input name="base_${name}" value="${d.base}"></div>`;
    });
  }

  const skillsBox=document.getElementById('parsedSkills');
  if(skillsBox){ skillsBox.innerHTML=''; Object.entries(data.skills).forEach(([k,v])=> skillsBox.innerHTML += `<div class="skill">${k} +${v}</div>`); }
  const percBox=document.getElementById('parsedPerc');
  if(percBox){ percBox.innerHTML=''; Object.entries(data.percs).forEach(([k,v])=> percBox.innerHTML += `<div class="skill">${k} ${v}%</div>`); }
  const condBox=document.getElementById('parsedConds');
  if(condBox){ condBox.innerHTML=''; data.conds.forEach(c=> condBox.innerHTML += `<span class="badge">${c}</span>`); }
  const effectsBox=document.getElementById('activeEffects');
  if(effectsBox){ effectsBox.innerHTML=''; data.effects.forEach(e=> effectsBox.innerHTML += `<div class="effect"><b>${e.name}</b><br>${e.effect_text}<br><b>${e.duration}</b> rounds remaining</div>`); }
  const messagesBox=document.getElementById('messagesBox');
  if(messagesBox){ messagesBox.innerHTML=''; data.messages.forEach(m=> messagesBox.innerHTML += `<div class="message"><b>${m.sender}</b> (${m.category})<br><br>${m.content}</div>`); }
}

async function refreshState(){
  if(!cid || cid === 'dm') return;
  const res = await fetch(`/state/${cid}`);
  if(res.ok) renderState(await res.json());
}

function startLive(){ polling=setInterval(refreshState, 2000); }

async function castSpell(spellId){
  await saveNow(false);
  const res = await fetch(`/cast_spell/${spellId}`, {method:'POST'});
  if(!res.ok){ const d=await res.json(); alert(d.message || 'Unable to cast spell'); }
  await refreshState();
}

async function toggleLoot(lootId){
  await saveNow(false);
  await fetch(`/toggle_loot/${lootId}`, {method:'POST'});
  await refreshState();
  location.reload();
}

document.addEventListener('DOMContentLoaded', startLive);
