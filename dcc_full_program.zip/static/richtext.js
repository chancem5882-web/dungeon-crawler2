function formatDoc(cmd, val=null){ document.execCommand(cmd, false, val); }
function makeToolbar(targetId){
  return `
  <div class="toolbar">
    <button type="button" onclick="formatDoc('bold')">B</button>
    <button type="button" onclick="formatDoc('italic')"><i>I</i></button>
    <button type="button" onclick="formatDoc('underline')"><u>U</u></button>
    <select onchange="formatDoc('fontName', this.value)">
      <option value="Arial">Arial</option><option value="Courier New">Courier</option><option value="Georgia">Georgia</option><option value="Impact">Impact</option>
    </select>
    <select onchange="formatDoc('fontSize', this.value)">
      <option value="3">Normal</option><option value="4">Large</option><option value="5">Huge</option><option value="6">Massive</option>
    </select>
    <input type="color" onchange="formatDoc('foreColor', this.value)" style="width:60px;padding:3px;">
  </div>`;
}
