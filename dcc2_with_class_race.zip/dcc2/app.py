import os
import re
import uuid
import sqlite3
from flask import Flask, render_template, request, redirect, jsonify, send_from_directory
from werkzeug.utils import secure_filename

app = Flask(__name__)

STATS = ["Strength", "Intelligence", "Dexterity", "Constitution", "Charisma"]


def get_storage():
    persistent = "/var/data"
    fallback = "./data"

    if os.path.exists(persistent):
        path = persistent
        mode = "PERSISTENT"
    else:
        path = fallback
        mode = "EPHEMERAL"

    os.makedirs(path, exist_ok=True)

    return {
        "mode": mode,
        "path": path,
        "db": os.path.join(path, "db.db"),
        "uploads": os.path.join(path, "uploads"),
    }


STORAGE = get_storage()
os.makedirs(STORAGE["uploads"], exist_ok=True)


def get_conn():
    conn = sqlite3.connect(STORAGE["db"], timeout=10)
    conn.execute("PRAGMA journal_mode=WAL;")
    return conn


def ensure_column(cursor, table, column, col_type):
    cursor.execute(f"PRAGMA table_info({table})")
    existing = [row[1] for row in cursor.fetchall()]
    if column not in existing:
        cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_type}")


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS characters(
        id TEXT PRIMARY KEY,
        name TEXT,
        image TEXT
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS stats(
        char_id TEXT,
        stat TEXT,
        base INT,
        buff INT,
        equip INT,
        PRIMARY KEY(char_id, stat)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS meta(
        char_id TEXT PRIMARY KEY,
        level INT,
        hp INT,
        max_hp INT,
        gold INT,
        views INT,
        followers INT,
        favorites INT,
        equipment TEXT,
        spells TEXT,
        inventory TEXT,
        class_features TEXT,
        race_features TEXT
    )
    """)

    # Migration safety for older versions of your database
    ensure_column(c, "characters", "image", "TEXT")
    ensure_column(c, "meta", "gold", "INT DEFAULT 0")
    ensure_column(c, "meta", "class_features", "TEXT DEFAULT ''")
    ensure_column(c, "meta", "race_features", "TEXT DEFAULT ''")

    c.execute("""
    CREATE TABLE IF NOT EXISTS parsed_skills(
        char_id TEXT,
        name TEXT,
        val INT,
        PRIMARY KEY(char_id, name)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS parsed_percentages(
        char_id TEXT,
        name TEXT,
        val INT,
        PRIMARY KEY(char_id, name)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS parsed_conditions(
        char_id TEXT,
        name TEXT,
        PRIMARY KEY(char_id, name)
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS effects(
        id TEXT PRIMARY KEY,
        char_id TEXT,
        name TEXT,
        value INT,
        duration INT,
        duration_type TEXT,
        is_buff INT
    )
    """)

    conn.commit()
    conn.close()


def clean(text):
    return re.sub(r"\s+", " ", (text or "").lower().replace("skill", "")).strip()


def safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def modifier(value):
    return value // 5


def parse_equipment(text):
    stat_bonus = {s: 0 for s in STATS}
    skill_bonus = {}
    percent_bonus = {}
    conditions = []

    for raw_line in (text or "").splitlines():
        line = raw_line.strip().lower()
        if not line:
            continue

        for cond in re.findall(r"\((.*?)\)", line):
            cond = clean(cond)
            if cond and cond not in conditions:
                conditions.append(cond)

        line = re.sub(r"\(.*?\)", "", line)

        percent_matches = re.finditer(
            r"([+-]?\d+)\s*%\s*([a-zA-Z ]+)|([a-zA-Z ]+)\s*([+-]?\d+)\s*%",
            line
        )

        for m in percent_matches:
            a, b, c, d = m.groups()
            val = safe_int(a or d, None)
            name = clean(b or c)

            if val is not None and name:
                percent_bonus[name] = percent_bonus.get(name, 0) + val

        line = re.sub(
            r"([+-]?\d+\s*%\s*[a-zA-Z ]+)|([a-zA-Z ]+\s*[+-]?\d+\s*%)",
            "",
            line
        )

        normal_matches = re.finditer(
            r"([+-]?\d+)\s*([a-zA-Z ]+)|([a-zA-Z ]+)\s*([+-]?\d+)",
            line
        )

        for m in normal_matches:
            a, b, c, d = m.groups()
            val = safe_int(a or d, None)
            name = clean(b or c)

            if val is None or not name:
                continue

            matched_stat = False
            for stat in STATS:
                if name.startswith(stat[:3].lower()):
                    stat_bonus[stat] += val
                    matched_stat = True
                    break

            if not matched_stat:
                skill_bonus[name] = skill_bonus.get(name, 0) + val

    return stat_bonus, skill_bonus, percent_bonus, conditions


@app.route("/")
def index():
    conn = get_conn()
    c = conn.cursor()
    c.execute("SELECT id, name, image FROM characters ORDER BY name")
    chars = c.fetchall()
    conn.close()

    return render_template("index.html", chars=chars, storage=STORAGE)


@app.route("/create", methods=["POST"])
def create():
    cid = str(uuid.uuid4())
    name = request.form.get("name", "Unnamed Crawler")

    conn = get_conn()
    c = conn.cursor()

    c.execute("INSERT INTO characters VALUES (?, ?, ?)", (cid, name, ""))

    for stat in STATS:
        c.execute("INSERT INTO stats VALUES (?, ?, ?, ?, ?)", (cid, stat, 10, 0, 0))

    c.execute("""
    INSERT INTO meta VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (cid, 1, 100, 100, 0, 0, 0, 0, "", "", "", "", ""))

    conn.commit()
    conn.close()

    return redirect(f"/c/{cid}")


@app.route("/image/<filename>")
def image(filename):
    return send_from_directory(STORAGE["uploads"], filename)


@app.route("/upload/<cid>", methods=["POST"])
def upload(cid):
    file = request.files.get("image")

    if file and file.filename:
        filename = secure_filename(file.filename)
        unique_name = f"{cid}_{filename}"
        save_path = os.path.join(STORAGE["uploads"], unique_name)
        file.save(save_path)

        web_path = f"/image/{unique_name}"

        conn = get_conn()
        c = conn.cursor()
        c.execute("UPDATE characters SET image=? WHERE id=?", (web_path, cid))
        conn.commit()
        conn.close()

    return redirect(f"/c/{cid}")


@app.route("/autosave/<cid>", methods=["POST"])
def autosave(cid):
    data = request.json or {}

    level = safe_int(data.get("level"), 1)
    hp = safe_int(data.get("hp"), 100)
    max_hp = max(safe_int(data.get("max_hp"), 100), 1)
    gold = safe_int(data.get("gold"), 0)
    views = safe_int(data.get("views"), 0)
    followers = safe_int(data.get("followers"), 0)
    favorites = safe_int(data.get("favorites"), 0)

    equipment = data.get("equipment", "")
    spells = data.get("spells", "")
    inventory = data.get("inventory", "")
    class_features = data.get("class_features", "")
    race_features = data.get("race_features", "")

    stat_b, skill_b, percent_b, conds = parse_equipment(equipment)

    conn = get_conn()
    c = conn.cursor()

    c.execute("""
    UPDATE meta SET
        level=?, hp=?, max_hp=?, gold=?, views=?, followers=?, favorites=?,
        equipment=?, spells=?, inventory=?, class_features=?, race_features=?
    WHERE char_id=?
    """, (
        level, hp, max_hp, gold, views, followers, favorites,
        equipment, spells, inventory, class_features, race_features, cid
    ))

    for stat in STATS:
        base = safe_int(data.get(f"base_{stat}"), 10)
        buff = safe_int(data.get(f"buff_{stat}"), 0)

        c.execute("""
        UPDATE stats SET base=?, buff=?, equip=?
        WHERE char_id=? AND stat=?
        """, (base, buff, stat_b[stat], cid, stat))

    c.execute("DELETE FROM parsed_skills WHERE char_id=?", (cid,))
    for name, val in skill_b.items():
        c.execute("INSERT INTO parsed_skills VALUES (?, ?, ?)", (cid, name, val))

    c.execute("DELETE FROM parsed_percentages WHERE char_id=?", (cid,))
    for name, val in percent_b.items():
        c.execute("INSERT INTO parsed_percentages VALUES (?, ?, ?)", (cid, name, val))

    c.execute("DELETE FROM parsed_conditions WHERE char_id=?", (cid,))
    for cond in conds:
        c.execute("INSERT INTO parsed_conditions VALUES (?, ?)", (cid, cond))

    c.execute("DELETE FROM effects WHERE char_id=?", (cid,))
    for effect in data.get("effects", []):
        name = effect.get("name", "").strip()
        if not name:
            continue

        c.execute("""
        INSERT INTO effects VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            str(uuid.uuid4()), cid, name,
            safe_int(effect.get("value"), 0),
            safe_int(effect.get("duration"), 0),
            effect.get("duration_type", "rounds"),
            1 if effect.get("is_buff") else 0
        ))

    conn.commit()
    conn.close()

    return jsonify({"status": "saved"})


@app.route("/c/<cid>")
def character(cid):
    conn = get_conn()
    c = conn.cursor()

    c.execute("SELECT id, name, image FROM characters WHERE id=?", (cid,))
    character_data = c.fetchone()

    if not character_data:
        conn.close()
        return redirect("/")

    c.execute("SELECT stat, base, buff, equip FROM stats WHERE char_id=?", (cid,))
    stats = {}

    for stat, base, buff, equip in c.fetchall():
        total = base + buff + equip
        stats[stat] = {"base": base, "buff": buff, "equip": equip, "total": total, "mod": modifier(total)}

    c.execute("SELECT * FROM meta WHERE char_id=?", (cid,))
    meta = c.fetchone()

    c.execute("SELECT name, val FROM parsed_skills WHERE char_id=? ORDER BY name", (cid,))
    skills = c.fetchall()

    c.execute("SELECT name, val FROM parsed_percentages WHERE char_id=? ORDER BY name", (cid,))
    percentages = c.fetchall()

    c.execute("SELECT name FROM parsed_conditions WHERE char_id=? ORDER BY name", (cid,))
    conditions = c.fetchall()

    c.execute("SELECT name, value, duration, duration_type, is_buff FROM effects WHERE char_id=?", (cid,))
    effects = c.fetchall()

    conn.close()

    return render_template(
        "character.html",
        cid=cid,
        character=character_data,
        stats=stats,
        meta=meta,
        skills=skills,
        percentages=percentages,
        conditions=conditions,
        effects=effects,
        storage=STORAGE
    )


init_db()

if __name__ == "__main__":
    app.run()
