const debounce=(fn,ms=450)=>{let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms)}};
async function post(url,data){const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});return r.json()}
function cidOf(el){return el.closest('[data-character]')?.dataset.character}
const saveChar=debounce(async(el)=>{const cid=cidOf(el); if(!cid)return; let v=el.type==='number'?Number(el.value):el.value; await post(`/api/character/${cid}`,{[el.dataset.save]:v}); markSaved(el)},500);
function markSaved(el){let p=el.closest('.card')?.querySelector('.autosave'); if(p){p.textContent='Saved '+new Date().toLocaleTimeString();}}
document.addEventListener('input',e=>{if(e.target.dataset.save)saveChar(e.target); if(e.target.dataset.entryField)saveEntry(e.target); if(e.target.dataset.buffField)saveBuff(e.target);});
document.addEventListener('change',e=>{if(e.target.dataset.buffField)saveBuff(e.target); if(e.target.dataset.giveLib){let cid=e.target.value;if(cid)post(`/api/library/${e.target.dataset.giveLib}/give`,{character_id:cid}).then(()=>location.reload())}});
const saveEntry=debounce(el=>{const wrap=el.closest('[data-entry]'); let val=el.type==='number'?Number(el.value):el.value; post(`/api/entry/${wrap.dataset.entry}`,{[el.dataset.entryField]:val});},500);
const saveBuff=debounce(el=>{const wrap=el.closest('[data-buff]'); let val=el.type==='checkbox'?(el.checked?1:0):(el.type==='number'?Number(el.value):el.value); post(`/api/buff/${wrap.dataset.buff}`,{[el.dataset.buffField]:val});},500);
function setupTabs(){document.querySelectorAll('.tabs').forEach(box=>{let buttons=box.querySelectorAll('[data-tab]'); buttons.forEach((b,i)=>b.onclick=()=>{box.querySelectorAll('.tab').forEach(t=>t.classList.remove('active')); box.querySelector('#tab-'+b.dataset.tab)?.classList.add('active')}); if(buttons[0])buttons[0].click();})}
setupTabs();
document.addEventListener('click',async e=>{
 if(e.target.dataset.addEntry){let cid=cidOf(e.target); await post('/api/entry',{character_id:cid,type:e.target.dataset.addEntry,name:'New '+e.target.dataset.addEntry,description:'',effect:'',qty:1,mana_cost:0}); location.reload()}
 if(e.target.dataset.addBuff!==undefined){let cid=cidOf(e.target); await post('/api/buff',{character_id:cid,name:'New Buff/Debuff',effect:'+1 STR, condition: Glowing',duration:'1 round',remaining:1}); location.reload()}
 if(e.target.dataset.deleteEntry){if(confirm('Delete this entry?')){await fetch('/api/entry/'+e.target.dataset.deleteEntry,{method:'DELETE'}); location.reload()}}
 if(e.target.dataset.deleteBuff){if(confirm('Delete this buff?')){await fetch('/api/buff/'+e.target.dataset.deleteBuff,{method:'DELETE'}); location.reload()}}
 if(e.target.dataset.cast){await post('/api/spell/'+e.target.dataset.cast+'/cast',{}); location.reload()}
 if(e.target.id==='tickAll'){await post('/api/tick_buffs',{}); location.reload()}
});
const lf=document.querySelector('#libraryForm'); if(lf)lf.addEventListener('submit',async e=>{e.preventDefault(); let data=Object.fromEntries(new FormData(lf).entries()); await post('/api/library',data); location.reload()});
