import os, re, json, sqlite3, uuid
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('DATABASE_PATH', BASE_DIR / 'data' / 'dcc.db'))
UPLOAD_DIR = BASE_DIR / 'static' / 'uploads'
ALLOWED_EXT = {'png','jpg','jpeg','gif','webp'}
STAT_KEYS = ['strength','intelligence','dexterity','constitution','charisma']

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY','dev-secret-change-me')
DM_PASSWORD = os.environ.get('DM_PASSWORD','crawler')

DB_PATH.parent.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# ---------- Database ----------
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS characters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL DEFAULT 'New Crawler', player_name TEXT DEFAULT '', class_name TEXT DEFAULT '', level INTEGER DEFAULT 1,
            gold INTEGER DEFAULT 0, hp_current INTEGER DEFAULT 10, hp_max INTEGER DEFAULT 10, mana_current INTEGER DEFAULT 0, mana_max INTEGER DEFAULT 0,
            strength INTEGER DEFAULT 10, intelligence INTEGER DEFAULT 10, dexterity INTEGER DEFAULT 10, constitution INTEGER DEFAULT 10, charisma INTEGER DEFAULT 10,
            notes TEXT DEFAULT '', profile_pic TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            character_id INTEGER NOT NULL, type TEXT NOT NULL, name TEXT NOT NULL DEFAULT '', description TEXT DEFAULT '', effect TEXT DEFAULT '', qty INTEGER DEFAULT 1,
            mana_cost INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS buffs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            character_id INTEGER NOT NULL, name TEXT NOT NULL, effect TEXT DEFAULT '', duration TEXT DEFAULT '', remaining INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS library (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL, name TEXT NOT NULL, description TEXT DEFAULT '', effect TEXT DEFAULT '', mana_cost INTEGER DEFAULT 0, price INTEGER DEFAULT 0, rarity TEXT DEFAULT 'Common', created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        ''')
        cur = con.execute('SELECT COUNT(*) AS c FROM characters')
        if cur.fetchone()['c'] == 0:
            con.execute("""INSERT INTO characters(name,player_name,class_name,level,gold,hp_current,hp_max,mana_current,mana_max,strength,intelligence,dexterity,constitution,charisma,notes)
            VALUES('Princess Murderpaws','Demo Player','Royal Chaos Bard',3,125,28,34,12,18,10,16,15,12,18,'Demo crawler. Delete or edit from the DM page.')""")
            cid = con.execute('SELECT last_insert_rowid()').fetchone()[0]
            con.execute("INSERT INTO entries(character_id,type,name,description,effect,qty) VALUES(?,?,?,?,?,?)", (cid,'equipment','Tiara of Questionable Decisions','A shiny crown with studio lighting built in.','+2 Charisma, +10% audience favor, condition: Fabulous',1))
            con.execute("INSERT INTO entries(character_id,type,name,description,effect,mana_cost,qty) VALUES(?,?,?,?,?,?,?)", (cid,'spell','Royal Screech','A piercing command that makes sponsors look up from lunch.','Damage 2d6 sonic; +2 intimidation',3,1))
            con.execute("INSERT INTO buffs(character_id,name,effect,duration,remaining) VALUES(?,?,?,?,?)", (cid,'Sponsor Spotlight','+1 Charisma, +15% visibility, condition: Glowing','3 rounds',3))
init_db()

# ---------- Helpers ----------
def allowed(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXT

def rowdicts(rows): return [dict(r) for r in rows]

def get_character(cid):
    with db() as con:
        ch = con.execute('SELECT * FROM characters WHERE id=?',(cid,)).fetchone()
        if not ch: return None
        entries = rowdicts(con.execute('SELECT * FROM entries WHERE character_id=? ORDER BY type,name',(cid,)).fetchall())
        buffs = rowdicts(con.execute('SELECT * FROM buffs WHERE character_id=? ORDER BY active DESC,id DESC',(cid,)).fetchall())
    d = dict(ch); d['entries']=entries; d['buffs']=buffs; d['parsed']=parse_character(d)
    return d

def parse_effects(text):
    text = text or ''
    stats = {k:0 for k in STAT_KEYS}; skills = {}; percentages = {}; conditions = []
    aliases = {'str':'strength','strength':'strength','int':'intelligence','intelligence':'intelligence','dex':'dexterity','dexterity':'dexterity','con':'constitution','constitution':'constitution','cha':'charisma','charisma':'charisma'}
    for m in re.finditer(r'([+-]\s*\d+)\s*(STR|Strength|INT|Intelligence|DEX|Dexterity|CON|Constitution|CHA|Charisma)\b', text, re.I):
        stats[aliases[m.group(2).lower()]] += int(m.group(1).replace(' ',''))
    for m in re.finditer(r'\b(STR|Strength|INT|Intelligence|DEX|Dexterity|CON|Constitution|CHA|Charisma)\s*([+-]\s*\d+)\b', text, re.I):
        stats[aliases[m.group(1).lower()]] += int(m.group(2).replace(' ',''))
    for m in re.finditer(r'([A-Za-z][A-Za-z\s\-/]{2,40}?)\s*([+-]\s*\d+)\b(?!\s*%)', text):
        name = m.group(1).strip(' ,.;:').lower()
        if name not in aliases and name not in ['damage','hp','mana','gold']:
            skills[name.title()] = skills.get(name.title(),0) + int(m.group(2).replace(' ',''))
    for m in re.finditer(r'([A-Za-z][A-Za-z\s\-/]{2,40}?)\s*([+-]?\s*\d+)\s*%', text):
        name = m.group(1).strip(' ,.;:').title()
        percentages[name] = percentages.get(name,0) + int(m.group(2).replace(' ',''))
    for m in re.finditer(r'(?:condition|status|special)\s*:\s*([^.;\n]+)', text, re.I):
        conditions.append(m.group(1).strip())
    for word in ['poisoned','stunned','burning','bleeding','invisible','flying','cursed','blessed','fragile','fabulous','glowing','silenced','restrained']:
        if re.search(r'\b'+re.escape(word)+r'\b', text, re.I): conditions.append(word.title())
    return {'stats':stats,'skills':skills,'percentages':percentages,'conditions':sorted(set(conditions))}

def merge_parse(target, parsed):
    for k,v in parsed['stats'].items(): target['stats'][k]=target['stats'].get(k,0)+v
    for k,v in parsed['skills'].items(): target['skills'][k]=target['skills'].get(k,0)+v
    for k,v in parsed['percentages'].items(): target['percentages'][k]=target['percentages'].get(k,0)+v
    target['conditions'] += parsed['conditions']

def parse_character(ch):
    total = {'stats':{k:0 for k in STAT_KEYS},'skills':{},'percentages':{},'conditions':[]}
    for e in ch.get('entries',[]):
        if e['type'] == 'equipment': merge_parse(total, parse_effects((e.get('name','')+' '+e.get('description','')+' '+e.get('effect',''))))
    for b in ch.get('buffs',[]):
        if b.get('active',1): merge_parse(total, parse_effects((b.get('name','')+' '+b.get('effect',''))))
    base = {k:int(ch.get(k,0) or 0) for k in STAT_KEYS}
    final = {k:base[k]+total['stats'].get(k,0) for k in STAT_KEYS}
    mods = {k: final[k]//5 for k in STAT_KEYS}
    total['base']=base; total['final']=final; total['mods']=mods; total['conditions']=sorted(set(total['conditions']))
    return total

def dm_required(): return session.get('dm') == True

# ---------- Pages ----------
@app.route('/')
def index():
    with db() as con: chars = rowdicts(con.execute('SELECT * FROM characters ORDER BY name').fetchall())
    return render_template('index.html', chars=chars)

@app.route('/character/new', methods=['POST'])
def new_character():
    with db() as con:
        cur=con.execute("INSERT INTO characters(name,player_name,class_name) VALUES(?,?,?)", (request.form.get('name') or 'New Crawler', request.form.get('player_name',''), request.form.get('class_name','')))
        cid=cur.lastrowid
    return redirect(url_for('character', cid=cid))

@app.route('/character/<int:cid>')
def character(cid):
    ch=get_character(cid)
    if not ch: return redirect(url_for('index'))
    return render_template('character.html', ch=ch, dm=False)

@app.route('/dm/login', methods=['GET','POST'])
def dm_login():
    if request.method=='POST':
        if request.form.get('password') == DM_PASSWORD:
            session['dm']=True; return redirect(url_for('dm'))
        flash('Wrong DM password. The dungeon AI is unimpressed.')
    return render_template('login.html')

@app.route('/dm/logout')
def dm_logout(): session.clear(); return redirect(url_for('index'))

@app.route('/dm')
def dm():
    if not dm_required(): return redirect(url_for('dm_login'))
    with db() as con:
        chars = rowdicts(con.execute('SELECT * FROM characters ORDER BY name').fetchall())
        library = rowdicts(con.execute('SELECT * FROM library ORDER BY type,name').fetchall())
    full=[]
    for c in chars: full.append(get_character(c['id']))
    return render_template('dm.html', chars=full, library=library)

# ---------- API ----------
@app.route('/api/character/<int:cid>', methods=['POST'])
def api_update_character(cid):
    data=request.get_json() or {}
    allowed_cols = ['name','player_name','class_name','level','gold','hp_current','hp_max','mana_current','mana_max','strength','intelligence','dexterity','constitution','charisma','notes']
    sets=[]; vals=[]
    for k in allowed_cols:
        if k in data:
            sets.append(f'{k}=?'); vals.append(data[k])
    if sets:
        vals.append(cid)
        with db() as con: con.execute(f"UPDATE characters SET {','.join(sets)}, updated_at=CURRENT_TIMESTAMP WHERE id=?", vals)
    return jsonify(ok=True, character=get_character(cid))

@app.route('/api/character/<int:cid>/upload', methods=['POST'])
def upload_pic(cid):
    f=request.files.get('profile_pic')
    if f and allowed(f.filename):
        ext=f.filename.rsplit('.',1)[1].lower(); filename=f'{cid}_{uuid.uuid4().hex}.{ext}'
        f.save(UPLOAD_DIR / secure_filename(filename))
        with db() as con: con.execute('UPDATE characters SET profile_pic=? WHERE id=?',(filename,cid))
    return redirect(request.referrer or url_for('character', cid=cid))

@app.route('/api/entry', methods=['POST'])
def api_entry():
    data=request.get_json() or request.form
    with db() as con:
        cur=con.execute('INSERT INTO entries(character_id,type,name,description,effect,qty,mana_cost) VALUES(?,?,?,?,?,?,?)',
            (data.get('character_id'), data.get('type','inventory'), data.get('name',''), data.get('description',''), data.get('effect',''), int(data.get('qty') or 1), int(data.get('mana_cost') or 0)))
    return jsonify(ok=True, id=cur.lastrowid)

@app.route('/api/entry/<int:eid>', methods=['POST','DELETE'])
def api_entry_update(eid):
    if request.method=='DELETE':
        with db() as con: con.execute('DELETE FROM entries WHERE id=?',(eid,))
        return jsonify(ok=True)
    data=request.get_json() or {}
    cols=['type','name','description','effect','qty','mana_cost']; sets=[]; vals=[]
    for k in cols:
        if k in data: sets.append(f'{k}=?'); vals.append(data[k])
    if sets:
        vals.append(eid)
        with db() as con: con.execute(f"UPDATE entries SET {','.join(sets)} WHERE id=?", vals)
    return jsonify(ok=True)

@app.route('/api/buff', methods=['POST'])
def api_buff():
    data=request.get_json() or request.form
    with db() as con:
        cur=con.execute('INSERT INTO buffs(character_id,name,effect,duration,remaining,active) VALUES(?,?,?,?,?,1)',
            (data.get('character_id'), data.get('name',''), data.get('effect',''), data.get('duration',''), int(data.get('remaining') or 0)))
    return jsonify(ok=True, id=cur.lastrowid)

@app.route('/api/buff/<int:bid>', methods=['POST','DELETE'])
def api_buff_update(bid):
    if request.method=='DELETE':
        with db() as con: con.execute('DELETE FROM buffs WHERE id=?',(bid,))
        return jsonify(ok=True)
    data=request.get_json() or {}
    cols=['name','effect','duration','remaining','active']; sets=[]; vals=[]
    for k in cols:
        if k in data: sets.append(f'{k}=?'); vals.append(data[k])
    if sets:
        vals.append(bid)
        with db() as con: con.execute(f"UPDATE buffs SET {','.join(sets)} WHERE id=?", vals)
    return jsonify(ok=True)

@app.route('/api/library', methods=['POST'])
def api_library():
    data=request.get_json() or request.form
    with db() as con:
        cur=con.execute('INSERT INTO library(type,name,description,effect,mana_cost,price,rarity) VALUES(?,?,?,?,?,?,?)',
            (data.get('type','loot'), data.get('name',''), data.get('description',''), data.get('effect',''), int(data.get('mana_cost') or 0), int(data.get('price') or 0), data.get('rarity','Common')))
    return jsonify(ok=True, id=cur.lastrowid)

@app.route('/api/library/<int:lid>/give', methods=['POST'])
def give_library(lid):
    data=request.get_json() or {}
    cid=data.get('character_id')
    with db() as con:
        item=con.execute('SELECT * FROM library WHERE id=?',(lid,)).fetchone()
        if item and cid:
            typ = 'spell' if item['type']=='spell' else ('equipment' if item['type']=='equipment' else 'inventory')
            con.execute('INSERT INTO entries(character_id,type,name,description,effect,qty,mana_cost) VALUES(?,?,?,?,?,?,?)',(cid,typ,item['name'],item['description'],item['effect'],1,item['mana_cost']))
    return jsonify(ok=True)

@app.route('/api/spell/<int:eid>/cast', methods=['POST'])
def cast_spell(eid):
    with db() as con:
        e=con.execute('SELECT * FROM entries WHERE id=?',(eid,)).fetchone()
        if not e: return jsonify(ok=False,error='Missing spell'),404
        ch=con.execute('SELECT mana_current FROM characters WHERE id=?',(e['character_id'],)).fetchone()
        new=max(0, int(ch['mana_current'])-int(e['mana_cost'] or 0))
        con.execute('UPDATE characters SET mana_current=? WHERE id=?',(new,e['character_id']))
    return jsonify(ok=True,mana_current=new)

@app.route('/api/tick_buffs', methods=['POST'])
def tick_buffs():
    data=request.get_json() or {}; ids=data.get('character_ids') or []
    q='SELECT * FROM buffs WHERE active=1 AND remaining>0' + (f" AND character_id IN ({','.join('?'*len(ids))})" if ids else '')
    with db() as con:
        rows=con.execute(q, ids).fetchall()
        for b in rows:
            rem=max(0,b['remaining']-1); active=1 if rem>0 else 0
            con.execute('UPDATE buffs SET remaining=?,active=? WHERE id=?',(rem,active,b['id']))
    return jsonify(ok=True)

@app.route('/api/parse_preview', methods=['POST'])
def parse_preview(): return jsonify(parse_effects((request.get_json() or {}).get('text','')))

if __name__ == '__main__': app.run(debug=True)
