import os, re, json, sqlite3, uuid
from datetime import datetime
from flask import Flask, render_template, request, jsonify, redirect, url_for
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, 'instance')
UPLOAD_DIR = os.path.join(BASE_DIR, 'static', 'uploads')
os.makedirs(INSTANCE_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
DB_PATH = os.environ.get('DATABASE_PATH', os.path.join(INSTANCE_DIR, 'dcc.db'))

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_DIR
app.config['MAX_CONTENT_LENGTH'] = 6 * 1024 * 1024

STATS = ['strength','intelligence','dexterity','constitution','charisma']
STAT_ALIASES = {
    'str':'strength','strength':'strength','int':'intelligence','intelligence':'intelligence',
    'dex':'dexterity','dexterity':'dexterity','con':'constitution','constitution':'constitution',
    'cha':'charisma','charisma':'charisma'
}
COND_WORDS = ['poisoned','stunned','blinded','burning','bleeding','fragile','invisible','frozen','cursed','blessed','shielded','hasted','slowed','charmed','feared','silenced','restrained','prone','exhausted']

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS characters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL DEFAULT 'New Crawler', class_name TEXT DEFAULT '', level INTEGER DEFAULT 1,
            hp_current INTEGER DEFAULT 10, hp_max INTEGER DEFAULT 10, mana_current INTEGER DEFAULT 0, mana_max INTEGER DEFAULT 0,
            gold INTEGER DEFAULT 0, strength INTEGER DEFAULT 10, intelligence INTEGER DEFAULT 10, dexterity INTEGER DEFAULT 10,
            constitution INTEGER DEFAULT 10, charisma INTEGER DEFAULT 10, profile_pic TEXT DEFAULT '', notes TEXT DEFAULT '',
            views INTEGER DEFAULT 0, followers INTEGER DEFAULT 0, favorites INTEGER DEFAULT 0, updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT, character_id INTEGER NOT NULL, kind TEXT NOT NULL,
            name TEXT NOT NULL DEFAULT '', description TEXT DEFAULT '', effect TEXT DEFAULT '', cost INTEGER DEFAULT 0,
            mana_cost INTEGER DEFAULT 0, equipped INTEGER DEFAULT 0, created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS buffs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, character_id INTEGER NOT NULL, name TEXT NOT NULL,
            effect TEXT DEFAULT '', duration INTEGER DEFAULT 1, duration_type TEXT DEFAULT 'rounds', active INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(character_id) REFERENCES characters(id) ON DELETE CASCADE
        );
        ''')
        cur = conn.execute('SELECT COUNT(*) n FROM characters')
        if cur.fetchone()['n'] == 0:
            conn.execute('INSERT INTO characters (name,class_name,level,hp_current,hp_max,mana_current,mana_max,gold,strength,intelligence,dexterity,constitution,charisma,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                         ('Princess Donut Adjacent','Unhinged Rockstar',3,32,32,18,18,120,12,14,16,13,18,'Welcome to the crawl.'))
            cid = conn.execute('SELECT id FROM characters LIMIT 1').fetchone()['id']
            conn.execute('INSERT INTO entries (character_id,kind,name,description,effect,equipped) VALUES (?,?,?,?,?,?)',(cid,'equipment','Managerial Crown of Bad Ideas','Shiny, cursed, and somehow tax deductible.','+3 CHA, +2 Bomb Handling, +15% attack speed, blessed',1))
            conn.execute('INSERT INTO entries (character_id,kind,name,description,effect,mana_cost) VALUES (?,?,?,?,?,?)',(cid,'spell','No Regurts','A flaming tattoo peels off and bites the enemy.','Deals chaos damage. +2 STR for 2 rounds. burning',4))
init_db()

def rows(sql, args=()):
    with db() as conn:
        return [dict(r) for r in conn.execute(sql, args).fetchall()]

def one(sql, args=()):
    with db() as conn:
        r = conn.execute(sql, args).fetchone()
        return dict(r) if r else None

def parse_effects(text):
    text = text or ''
    out = {'stats':{}, 'skills':{}, 'percentages':{}, 'conditions':[]}
    # +3 STR / -2 Constitution
    for amt, label in re.findall(r'([+-]\s*\d+)\s*(strength|str|intelligence|int|dexterity|dex|constitution|con|charisma|cha)\b', text, flags=re.I):
        stat = STAT_ALIASES[label.lower()]
        out['stats'][stat] = out['stats'].get(stat,0) + int(amt.replace(' ',''))
    # +2 Bomb Handling or Bomb Handling +2
    for amt, label in re.findall(r'([+-]\s*\d+)\s*([A-Za-z][A-Za-z ]{2,35})(?=,|;|\.|$)', text):
        clean = label.strip().lower()
        if clean not in STAT_ALIASES and not any(w in clean for w in ['round','hour','gold','hp','mana']):
            name = clean.title()
            out['skills'][name] = out['skills'].get(name,0) + int(amt.replace(' ',''))
    for label, amt in re.findall(r'([A-Za-z][A-Za-z ]{2,35})\s*([+-]\s*\d+)(?=,|;|\.|$)', text):
        clean = label.strip().lower()
        if clean not in STAT_ALIASES and not any(w in clean for w in ['round','hour','gold','hp','mana']):
            name = clean.title()
            out['skills'][name] = out['skills'].get(name,0) + int(amt.replace(' ',''))
    # percentages: attack speed +10%, +15% crit chance
    for label, amt in re.findall(r'([A-Za-z][A-Za-z ]{2,35})\s*([+-]?\s*\d+)\s*%', text):
        name = label.strip().title()
        out['percentages'][name] = out['percentages'].get(name,0) + int(amt.replace(' ',''))
    for amt, label in re.findall(r'([+-]?\s*\d+)\s*%\s*([A-Za-z][A-Za-z ]{2,35})', text):
        name = label.strip().title()
        out['percentages'][name] = out['percentages'].get(name,0) + int(amt.replace(' ',''))
    low = text.lower()
    for c in COND_WORDS:
        if re.search(r'\b'+re.escape(c)+r'\b', low): out['conditions'].append(c.title())
    return out

def character_bundle(cid):
    c = one('SELECT * FROM characters WHERE id=?', (cid,))
    if not c: return None
    entries = rows('SELECT * FROM entries WHERE character_id=? ORDER BY kind,name', (cid,))
    buffs = rows('SELECT * FROM buffs WHERE character_id=? AND active=1 ORDER BY id DESC', (cid,))
    aggregate = {'stats':{}, 'skills':{}, 'percentages':{}, 'conditions':[]}
    sources = [e for e in entries if e['kind']=='equipment' and e['equipped']] + buffs
    for s in sources:
        parsed = parse_effects((s.get('effect') or '') + ' ' + (s.get('description') or ''))
        for k,v in parsed['stats'].items(): aggregate['stats'][k]=aggregate['stats'].get(k,0)+v
        for k,v in parsed['skills'].items(): aggregate['skills'][k]=aggregate['skills'].get(k,0)+v
        for k,v in parsed['percentages'].items(): aggregate['percentages'][k]=aggregate['percentages'].get(k,0)+v
        aggregate['conditions'] += parsed['conditions']
    aggregate['conditions'] = sorted(set(aggregate['conditions']))
    totals = {s: int(c[s]) + aggregate['stats'].get(s,0) for s in STATS}
    mods = {s: totals[s]//5 for s in STATS}
    c['entries'] = entries; c['buffs'] = buffs; c['parsed'] = aggregate; c['totals'] = totals; c['mods'] = mods
    return c

@app.route('/')
def index():
    return render_template('index.html', characters=rows('SELECT * FROM characters ORDER BY name'))

@app.route('/character/<int:cid>')
def character(cid):
    return render_template('character.html', c=character_bundle(cid))

@app.route('/dm')
def dm_page():
    return render_template('dm.html', characters=[character_bundle(x['id']) for x in rows('SELECT id FROM characters ORDER BY name')])

@app.post('/api/character')
def create_character():
    name = request.json.get('name','New Crawler')
    with db() as conn:
        cur = conn.execute('INSERT INTO characters (name) VALUES (?)', (name,))
        cid = cur.lastrowid
    return jsonify({'ok':True,'id':cid})

@app.get('/api/character/<int:cid>')
def get_character(cid): return jsonify(character_bundle(cid))

@app.post('/api/character/<int:cid>')
def update_character(cid):
    data = request.json or {}; allowed = ['name','class_name','level','hp_current','hp_max','mana_current','mana_max','gold','strength','intelligence','dexterity','constitution','charisma','notes','views','followers','favorites']
    fields = [k for k in allowed if k in data]
    if fields:
        sql = ', '.join([f'{k}=?' for k in fields]) + ', updated_at=CURRENT_TIMESTAMP'
        vals = [data[k] for k in fields] + [cid]
        with db() as conn: conn.execute(f'UPDATE characters SET {sql} WHERE id=?', vals)
    return jsonify({'ok':True,'character':character_bundle(cid)})

@app.post('/api/character/<int:cid>/upload')
def upload(cid):
    f = request.files.get('profile_pic')
    if not f: return redirect(url_for('character', cid=cid))
    ext = os.path.splitext(secure_filename(f.filename))[1].lower() or '.png'
    filename = f'{cid}_{uuid.uuid4().hex}{ext}'
    f.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    with db() as conn: conn.execute('UPDATE characters SET profile_pic=? WHERE id=?', (filename,cid))
    return redirect(request.referrer or url_for('character', cid=cid))

@app.post('/api/entry')
def save_entry():
    d = request.json or {}
    with db() as conn:
        if d.get('id'):
            conn.execute('UPDATE entries SET kind=?,name=?,description=?,effect=?,cost=?,mana_cost=?,equipped=? WHERE id=?', (d['kind'],d.get('name',''),d.get('description',''),d.get('effect',''),d.get('cost',0),d.get('mana_cost',0),1 if d.get('equipped') else 0,d['id']))
            eid=d['id']
        else:
            cur=conn.execute('INSERT INTO entries (character_id,kind,name,description,effect,cost,mana_cost,equipped) VALUES (?,?,?,?,?,?,?,?)',(d['character_id'],d['kind'],d.get('name',''),d.get('description',''),d.get('effect',''),d.get('cost',0),d.get('mana_cost',0),1 if d.get('equipped') else 0)); eid=cur.lastrowid
    return jsonify({'ok':True,'id':eid})

@app.delete('/api/entry/<int:eid>')
def del_entry(eid):
    with db() as conn: conn.execute('DELETE FROM entries WHERE id=?',(eid,))
    return jsonify({'ok':True})

@app.post('/api/buff')
def save_buff():
    d=request.json or {}
    with db() as conn:
        cur=conn.execute('INSERT INTO buffs (character_id,name,effect,duration,duration_type) VALUES (?,?,?,?,?)',(d['character_id'],d.get('name','Buff'),d.get('effect',''),d.get('duration',1),d.get('duration_type','rounds')))
    return jsonify({'ok':True,'id':cur.lastrowid})

@app.post('/api/buff/<int:bid>/tick')
def tick_buff(bid):
    with db() as conn:
        b=conn.execute('SELECT * FROM buffs WHERE id=?',(bid,)).fetchone()
        if b:
            new=max(0,b['duration']-1)
            conn.execute('UPDATE buffs SET duration=?, active=? WHERE id=?',(new,1 if new>0 else 0,bid))
    return jsonify({'ok':True})

@app.delete('/api/buff/<int:bid>')
def del_buff(bid):
    with db() as conn: conn.execute('UPDATE buffs SET active=0 WHERE id=?',(bid,))
    return jsonify({'ok':True})

@app.post('/api/cast/<int:eid>')
def cast_spell(eid):
    e=one('SELECT * FROM entries WHERE id=?',(eid,));
    if not e: return jsonify({'ok':False}),404
    c=one('SELECT mana_current FROM characters WHERE id=?',(e['character_id'],))
    new=max(0,int(c['mana_current'])-int(e['mana_cost'] or 0))
    with db() as conn: conn.execute('UPDATE characters SET mana_current=? WHERE id=?',(new,e['character_id']))
    return jsonify({'ok':True,'mana_current':new})

if __name__ == '__main__':
    app.run(debug=True)
