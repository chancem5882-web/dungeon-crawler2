const qs=s=>document.querySelector(s);
async function post(url,data){let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});return r.json()}
function debounce(fn,ms=450){let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms)}}
const save=debounce(async el=>{let box=el.closest('.sheet'),cid=box?.dataset.cid;if(!cid)return;let val=el.type==='number'?Number(el.value):el.value;el.classList.add('saving');await post(`/api/character/${cid}`,{[el.dataset.field]:val});el.classList.remove('saving');el.classList.add('saved');setTimeout(()=>el.classList.remove('saved'),500)},350);
document.addEventListener('input',e=>{if(e.target.classList.contains('autosave'))save(e.target)});
async function createChar(){let name=qs('#newName')?.value||'New Crawler';let j=await post('/api/character',{name});location.href='/character/'+j.id}
async function addEntry(cid,kind){let data={character_id:cid,kind,name:qs(`#${kind}Name`).value,description:qs(`#${kind}Desc`).value,effect:qs(`#${kind}Effect`).value,mana_cost:Number(qs(`#${kind}Mana`)?.value||0),equipped:kind==='equipment'};await post('/api/entry',data);location.reload()}
async function quickEntry(id,cid,kind,cb){let item=cb.closest('.item');await post('/api/entry',{id,character_id:cid,kind,name:item.querySelector('b').innerText,description:item.querySelector('p').innerText,effect:item.querySelector('small').innerText,equipped:cb.checked});location.reload()}
async function deleteEntry(id){await fetch('/api/entry/'+id,{method:'DELETE'});location.reload()}
async function addBuff(cid){await post('/api/buff',{character_id:cid,name:qs('#buffName').value,effect:qs('#buffEffect').value,duration:Number(qs('#buffDuration').value),duration_type:qs('#buffType').value});location.reload()}
async function tickBuff(id){await post(`/api/buff/${id}/tick`,{});location.reload()}
async function deleteBuff(id){await fetch('/api/buff/'+id,{method:'DELETE'});location.reload()}
async function castSpell(id){await post('/api/cast/'+id,{});location.reload()}
async function dmGrant(cid){await post('/api/entry',{character_id:cid,kind:qs(`#kind${cid}`).value,name:qs(`#name${cid}`).value,description:qs(`#desc${cid}`).value,effect:qs(`#effect${cid}`).value,mana_cost:Number(qs(`#mana${cid}`).value||0),equipped:qs(`#kind${cid}`).value==='equipment'});location.reload()}
async function dmBuff(cid){await post('/api/buff',{character_id:cid,name:qs(`#buffName${cid}`).value,effect:qs(`#buffEffect${cid}`).value,duration:Number(qs(`#buffDuration${cid}`).value),duration_type:'rounds'});location.reload()}
